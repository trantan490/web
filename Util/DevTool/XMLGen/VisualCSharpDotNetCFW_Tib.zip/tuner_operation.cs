        
        public abstract void %%OperationName%%(%%caster_operation_parameter%%);
        private void recv_%%OperationName%%(Session issuer, Message msg)
        {
            StreamTransformer former = new StreamTransformerImpl((byte[])msg.getData());
%%tuner_operation_parameter_def%%
            %%tuner_operation_parameter_transform%%
            %%OperationName%%(%%caster_operation_parameter_name%%); /* Call User Procedure */
            %%tuner_operation_request.cs:REPEAT%%
        }

