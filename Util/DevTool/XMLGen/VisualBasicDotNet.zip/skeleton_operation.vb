
    Public Sub %%OperationName%%( _
%%caster_operation_parameter%%
        )
        
        Try
            // TODO : User code
        Catch ex As Exception
            // TODO : Exception process
        End Try
    End Sub

