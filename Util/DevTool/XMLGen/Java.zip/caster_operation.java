    public static boolean %%OperationName%%(%%caster_operation_parameter%%)
    {
        return %%OperationName%%(%%caster_operation_parameter_name%%, "", 0, DeliveryType.%%DeliveryMode%%);
    }
    public static boolean %%OperationName%%(%%caster_operation_parameter%%, String channel, int ttl, short mode)
    {
        try
        {
            if (null == channel || channel.trim().equals(""))
            {
                if (null == get%%ModuleName%%Channel() || get%%ModuleName%%Channel().trim().equals(""))
                    throw new Exception("Invalid Channel!");

                channel = get%%ModuleName%%Channel();
            }
            ttl = ttl <= 0 ? get%%ModuleName%%TTL() : ttl;

            Message msg = %%StubFileName%%.getInstance().createMessage();
            msg.putProperty(%%StubFileName%%.XGEN_TAG_VERSION, %%StubFileName%%.XGEN_VERSION);
            msg.putProperty(%%StubFileName%%.XGEN_TAG_MODULE, "%%ModuleName%%");
            msg.putProperty(%%StubFileName%%.XGEN_TAG_INTERFACE, "%%ModuleName%%");
            msg.putProperty(%%StubFileName%%.XGEN_TAG_OPERATION, "%%OperationName%%");
            
            StreamTransformer former = new StreamTransformerImpl();
            %%caster_operation_parameter_serialize%%
            msg.putData(former.getBytes());

            Message rep = %%StubFileName%%.getInstance().sendMessage(msg, channel, ttl, mode);
            %%caster_operation_request.java:REPEAT%%

	    	return true;
	    }
        catch(Exception e)
        {
            %%StubFileName%%.setMessage(e.getMessage());
            return false;
        }
    }


