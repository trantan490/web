
            if (DeliveryType.REQUEST == mode) /* Just RequestReply */
            {
                if(null == rep)
                    throw new Exception("Invalid Message!");

                former = new StreamTransformerImpl((byte[]) rep.getData());
                %%caster_operation_parameter_transform%%
            }
