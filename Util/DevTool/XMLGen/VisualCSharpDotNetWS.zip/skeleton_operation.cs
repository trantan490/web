
        public override void %%OperationName%%(%%caster_operation_parameter%%)
        {
            try
            {
                // TODO : User code

            }
            catch(Exception e)
            {
                // TODO : Exception process
                throw e;
            }
        }

