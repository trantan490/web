                former = new StreamTransformerImpl(aReplyData);
                %%caster_operation_parameter_transform%%
