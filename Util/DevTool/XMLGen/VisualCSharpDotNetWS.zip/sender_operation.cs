        public static bool %%OperationName%%(%%caster_operation_parameter%%)
        {
            return %%OperationName%%("%%OperationName%%", %%caster_operation_parameter_name%%);
        }
        public static bool %%OperationName%%(string FunctionName, %%caster_operation_parameter%%)
        {
            try
            {
                if (null == %%ModuleName%%Url || %%ModuleName%%Url.Trim().Equals(""))
                        throw new Exception("INVALID_URL");

                if (0 >= %%ModuleName%%TimeOut)
                        throw new Exception("INVALID_TIMEOUT");

                string sReplyMsg = null;
                string sSendMsg = null;
                byte[] aReplyData = null;
                SmartWebService oWebService = new SmartWebService();
                StreamTransformer former = new StreamTransformerImpl();

                oWebService.SetUrl(%%ModuleName%%Url);
                oWebService.SetTimeOut(%%ModuleName%%TimeOut);
                
                %%caster_operation_parameter_serialize%%
                
                sSendMsg = FwxCmnFunction.PackMessage(former.getBytes());
                oWebService.RequestReply(FunctionName, sSendMsg, ref sReplyMsg);
                aReplyData = FwxCmnFunction.UnPackMessage(sReplyMsg);

%%sender_operation_request.cs:REPEAT%%

    	    	return true;
    	    }
            catch(Exception ex)
            {
                throw ex;
            }
        }


