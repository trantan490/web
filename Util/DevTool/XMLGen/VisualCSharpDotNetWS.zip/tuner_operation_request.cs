
            if (DeliveryType.isRequest(msg.getDeliveryMode())) /* Just RequestReply */
            {
                Message rep = msg.createReply();
                former = new StreamTransformerImpl();
                %%tuner_operation_parameter_serialize%%
                rep.putData(former.getBytes());
                %%StubFileName%%.Instance.sendReply(issuer, msg, rep, "000", "");
            }
