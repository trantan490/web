
            former = new StreamTransformerImpl();
            %%transfer_operation_parameter_serialize%%

            sReply = FwxCmnFunction.PackMessage(former.getBytes());
