        
        public abstract void %%OperationName%%(%%caster_operation_parameter%%);
        public void recv_%%OperationName%%(string sRequest, ref string sReply)
        {
            byte[] outByt = FwxCmnFunction.UnPackMessage(sRequest);
            StreamTransformer former = new StreamTransformerImpl(outByt);
            %%transfer_operation_parameter_def%%
            %%tuner_operation_parameter_transform%%
            %%OperationName%%(%%caster_operation_parameter_name%%); /* Call User Procedure */
            %%transfer_operation_request.cs:REPEAT%%
        }

