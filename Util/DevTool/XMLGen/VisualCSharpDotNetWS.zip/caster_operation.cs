        public static bool %%OperationName%%(%%caster_operation_parameter%%)
        {
            return %%OperationName%%(%%caster_operation_parameter_name%%, "", 0, DeliveryType.%%DeliveryMode%%);
        }
        public static bool %%OperationName%%(%%caster_operation_parameter%%, string channel, int ttl, short mode)
        {
            try
            {
                if (null == channel || channel.Trim().Equals(""))
                {
                    if (null == %%ModuleName%%Channel || %%ModuleName%%Channel.Trim().Equals(""))
                        throw new TrxException(TrxException.INVALID_CHANNEL);

                    channel = %%ModuleName%%Channel;
                }
                ttl = ttl <= 0 ? %%ModuleName%%TTL : ttl;

                Message msg = %%StubFileName%%.Instance.createMessage();
                msg.putProperty(%%StubFileName%%.XGEN_TAG_VERSION, %%StubFileName%%.XGEN_VERSION);
                msg.putProperty(%%StubFileName%%.XGEN_TAG_MODULE, "%%ModuleName%%");
                msg.putProperty(%%StubFileName%%.XGEN_TAG_INTERFACE, "%%ModuleName%%");
                msg.putProperty(%%StubFileName%%.XGEN_TAG_OPERATION, "%%OperationName%%");
                
                StreamTransformer former = new StreamTransformerImpl();
                %%caster_operation_parameter_serialize%%
                msg.putData(former.getBytes());

                Message rep = null;
                %%StubFileName%%.Instance.sendMessage(msg, ref rep, channel, ttl, mode);
                %%caster_operation_request.cs:REPEAT%%

    	    	return true;
    	    }
            catch(Exception e)
            {
                %%StubFileName%%.StatusMessage = e.Message;
                return false;
            }
        }


