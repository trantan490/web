
                if (DeliveryType.REQUEST == mode) /* Just RequestReply */
                {
                    if(null == rep)
                        throw new TrxException(TrxException.INVALID_MESSAGE);

                    former = new StreamTransformerImpl((byte[]) rep.getData());
                    %%caster_operation_parameter_transform%%
                }
