    ' Function %%OperationName%%
    Public Shared Function %%OperationName%%( _
%%caster_operation_parameter%%                
        Optional ByVal channel As String = "", _
        Optional ByVal ttl As Integer = 0, _
        Optional ByVal mode As H101MessageDeliveryMode = H101MessageDeliveryMode.%%DeliveryMode%%, _
        Optional ByVal sync As Boolean = %%Sync%%) As Integer

        Try
            Dim former As com.miracom.transceiverx.message.former.StreamTransformer = Nothing
            Dim request As com.miracom.transceiverx.message.Message = Nothing

            ' Reset Result Code, Message
            setH101Result(H101_SUCCESS, "")
            
            channel = IIf(("" = channel), %%ModuleName%%Channel, channel)
            ttl = IIf((0 >= ttl), %%ModuleName%%TTL, ttl)

            request = getH101Stub().createMessage
            request.putProperty(H101_XGEN_TAG_VERSION, H101_XGEN_VERSION)
            request.putProperty(H101_XGEN_TAG_MODULE, "%%ModuleName%%")
            request.putProperty(H101_XGEN_TAG_INTERFACE, "%%ModuleName%%")
            request.putProperty(H101_XGEN_TAG_OPERATION, "%%OperationName%%")

            ' Marshalling(Serialize) input parameter
            former = New com.miracom.transceiverx.message.former.StreamTransformerImpl

            %%caster_operation_parameter_serialize%%
            
            request.putData(former.getBytes())

            ' Send message
            Dim reply As com.miracom.transceiverx.message.Message = Nothing
            
            getH101Stub().send(channel, request, reply, ttl, mode, sync)
            If (H101_SUCCESS <> getH101Result().code) Then
                Return getH101Result().code
            End If

            ' Just RequestReply
            If (H101MessageDeliveryMode.REQUEST = mode) Then
                If (reply Is Nothing) Then
                    Return getH101Result().code
                End If

                setH101Result(CLng(reply.getProperty("RESULT_CODE")), CStr(reply.getProperty("RESULT_MSG")))
                If (H101_SUCCESS <> getH101Result().code) Then
                    Return getH101Result().code
                End If

                ' Unmarshalling(Transform) output parameter
                Dim bytes As Byte()
                bytes = reply.getData()
                former = New com.miracom.transceiverx.message.former.StreamTransformerImpl(bytes)
                
                %%caster_operation_parameter_transform%%
                
            End If
        Catch ex As Exception
            Return setH101Result(Err.Number, Err.Description)
        End Try
    End Function

