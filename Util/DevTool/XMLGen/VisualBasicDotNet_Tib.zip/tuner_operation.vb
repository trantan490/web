
    ' Function recv_%%OperationName%%
    Public Shared Function recv_%%OperationName%%( _
        ByVal session As com.miracom.transceiverx.session.Session, _
        ByVal request As com.miracom.transceiverx.message.Message) As Integer

        Try
            Dim former As com.miracom.transceiverx.message.former.StreamTransformer = Nothing
            Dim ioiStatus As Integer = H101_SUCCESS

%%tuner_operation_parameter_def%%
            ' Reset Result Code, Message
            setH101Result(H101_SUCCESS, "")

            ' Unmarshalling Input Parameter
            former = New com.miracom.transceiverx.message.former.StreamTransformerImpl(request.getData())
            %%tuner_operation_parameter_transform%%    

            ' Call User Procedure
            ioiStatus = %%OperationName%%(%%caster_operation_parameter_name%%)
            If (com.miracom.transceiverx.session.DeliveryType.isRequest(request.getDeliveryMode())) Then
                Dim reply As com.miracom.transceiverx.message.Message = Nothing
                reply = request.createReply()
                reply.putProperty(H101_XGEN_TAG_VERSION, H101_XGEN_VERSION)
                reply.putProperty(H101_XGEN_TAG_MODULE, "%%ModuleName%%")
                reply.putProperty(H101_XGEN_TAG_INTERFACE, "%%ModuleName%%")
                reply.putProperty(H101_XGEN_TAG_OPERATION, "%%OperationName%%")
                reply.putProperty(H101_XGEN_TAG_HOSTNAME, getH101Stub().getLastHostName())
                reply.putProperty(H101_XGEN_TAG_HOSTADDR, getH101Stub().getLastHostAddr())
                reply.putProperty("RESULT_CODE", "000")
                reply.putProperty("RESULT_MSG", "")
                reply.putTTL(request.getTTL())

                ' Marshalling Output Parameter
                former = New com.miracom.transceiverx.message.former.StreamTransformerImpl
                %%tuner_operation_parameter_serialize%%

                reply.putData(former.getBytes())

                ' Send Reply Message
                session.SendReply(request, reply)
            End If
        Catch ex As Exception
        End Try

        Return setH101Result(Err.Number, Err.Description)
    End Function

