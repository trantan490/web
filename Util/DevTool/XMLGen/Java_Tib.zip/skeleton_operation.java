
    public void %%OperationName%%(%%caster_operation_parameter%%) throws Exception
    {
        // TODO : User code
    }

