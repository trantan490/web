        public static bool %%OperationName%%(%%caster_operation_parameter%%)
        {
            return %%OperationName%%(%%caster_operation_parameter_name%%, "", 0);
        }
        public static bool %%OperationName%%(%%caster_operation_parameter%%, string channel, double ttl)
        {
            try
            {
                if (null == channel || channel.Trim().Equals(""))
                {
                    if (null == %%ModuleName%%Channel || %%ModuleName%%Channel.Trim().Equals(""))
                        throw new Exception("Invalid channel");

                    channel = %%ModuleName%%Channel;
                }
                ttl = ttl <= 0 ? %%ModuleName%%TTL : ttl;

                Message req = new Message();
                req.AddField(CMessageType.MODULE, "%%ModuleName%%", 0);
                req.AddField(CMessageType.FUNCTION_NAME, "%%OperationName%%", 0);

                %%caster_operation_parameter_serialize%%

                Message rep = null;
                CMessage.Instance.%%DeliveryFunctionCall%%
                %%caster_operation_request.cs:REPEAT%%

                return true;
            }
            catch(Exception e)
            {
                CMessage.StatusMessage = e.Message;
                return false;
            }
        }


