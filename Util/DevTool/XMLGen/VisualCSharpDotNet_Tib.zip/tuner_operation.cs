        
        public abstract void %%OperationName%%(%%caster_operation_parameter%%);
        private void recv_%%OperationName%%(Message msg, bool replyExpected, int messageId)
        {
%%tuner_operation_parameter_def%%
            %%tuner_operation_parameter_transform%%
            %%OperationName%%(%%caster_operation_parameter_name%%); /* Call User Procedure */
            %%tuner_operation_request.cs:REPEAT%%
        }

