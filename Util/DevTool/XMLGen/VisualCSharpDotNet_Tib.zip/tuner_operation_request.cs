
            if (replyExpected == true) /* Just RequestReply */
            {
                Message rep = new TIBCO.Rendezvous.Message();
                %%tuner_operation_parameter_serialize%%
                CMessage.Instance.reply(rep, messageId, msg.ReplySubject);
            }
