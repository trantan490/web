extern int recv_%%OperationName%%(tibrvEvent event, tibrvMsg message, void* closure);

