
        if((IOI_SUCCESS == status) && (DT_REQUEST == mode) && (Null_Ptr != rep)) /* Just RequestReply */
        {
            a_data = IOIMessageGetDataArray(rep);
            former = CreateByteTransformer(&a_data);
            if(Null_Ptr != former)
            {
                %%caster_operation_parameter_transform%%
            }
                DestroyTransformer(former);
            if(rep) IOIMessageRelease(rep);
        }
