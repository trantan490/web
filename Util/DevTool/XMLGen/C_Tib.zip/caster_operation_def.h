extern IOIStatus send_%%OperationName%%(%%caster_operation_parameter%%, LPTSTR channel, int ttl, int mode);

