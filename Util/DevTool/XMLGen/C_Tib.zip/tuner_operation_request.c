
	    if(b_reply_expected == TIBRV_TRUE)
	    {
		    if (TIBRV_OK != tibrvMsg_Create(&send_message)) return 0;
		    if (TIBRV_OK != tibrvMsg_Reset(send_message)) return 0;

            %%tuner_operation_parameter_serialize%%

		    CMessage_reply(i_msg_id, send_message, &status_val, status_msg);
		    if(status_val != CMESSAGE_SUCCESS)
		    {
			    tibrvMsg_Destroy(send_message);
			    return 0;
		    }

		    tibrvMsg_Destroy(send_message);
	    }
