IOIStatus send_%%OperationName%%(%%caster_operation_parameter%%, LPTSTR channel, int ttl, int mode)
{
    IOIStatus status = IOI_SUCCESS;
    IOIMessage rep = Null_Ptr;
    IOIMessage msg = IOIMessageCreate();
    if(Null_Ptr == msg) return IOIGetLastError();

    ttl = (0 < ttl) ? ttl : XGEN_DEFAULT_TTL;
    mode = (0 < mode && mode <= 6) ? mode : %%DeliveryMode%%;

    IOIMessageAddStringInfo(msg, XGEN_TAG_VERSION,   (short)TSTRLEN(XGEN_VERSION), XGEN_VERSION);
    IOIMessageAddStringInfo(msg, XGEN_TAG_HOSTNAME,  (short)TSTRLEN(mioi_hostname), mioi_hostname);
    IOIMessageAddStringInfo(msg, XGEN_TAG_HOSTADDR,  (short)TSTRLEN(mioi_hostaddr), mioi_hostaddr);
    IOIMessageAddStringInfo(msg, XGEN_TAG_MODULE,    (short)TSTRLEN(_T("%%ModuleName%%")), _T("%%ModuleName%%"));
    IOIMessageAddStringInfo(msg, XGEN_TAG_INTERFACE, (short)TSTRLEN(_T("%%ModuleName%%")), _T("%%ModuleName%%"));
    IOIMessageAddStringInfo(msg, XGEN_TAG_OPERATION, (short)TSTRLEN(_T("%%OperationName%%")), _T("%%OperationName%%"));

    if(Null_Ptr != msg)
    {
        IxArray a_data;
        HStreamBuffer buffer = CreateStreamByteBuffer(Null_Ptr, IX_BYTE, XGEN_BLOCK_INIT_COUNT, XGEN_BLOCK_INC_COUNT, XGEN_BLOCK_SIZE);
        HOutputStream stream = CreateOutputStream(buffer);
        HTransformer  former = CreateWriteTransformer(stream);
        if(Null_Ptr != former)
        {
            %%caster_operation_parameter_serialize%%
            DestroyTransformer(former);
        }

        DestroyOutputStream(stream);
        a_data = StreamBuffer_GetBytes(buffer);
        IOIMessageSetData(msg, a_data.pval, a_data.cnt); 
        DestroyStreamBuffer(buffer);
        array_destroy(&a_data);
        
        status = send_message(msg, &rep, channel, ttl, mode, True32);
        %%caster_operation_request.c:REPEAT%%        
    }

    if(msg) IOIMessageRelease(msg);

    return status;
}


