extern int %%OperationName%%(%%caster_operation_parameter%%);

