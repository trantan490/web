int recv_%%OperationName%%(tibrvEvent event, tibrvMsg message, void* closure)
{
	tibrv_status	status;
	unsigned short 	status_val;
	char		    status_msg[SIZE_MSG];
    tibrv_i32       i_msg_id;
	tibrv_bool	    b_reply_expected;
	tibrvMsg	    send_message;
    
%%tuner_operation_parameter_def%%
    STSINIT(&status_val, status_msg);
    i_msg_id = 0;
    b_reply_expected = TIBRV_FALSE;
    send_message = 0x00;
    
    if(message != 0x00)
    {
        %%tuner_operation_parameter_transform%%

        %%OperationName%%(%%tuner_operation_parameter_name%%); /* Call User Procedure */

        status = tibrvMsg_GetI32(message, "__msg_id", &i_msg_id);
    	status = tibrvMsg_GetBool(message, "__reply_expected", &b_reply_expected);
        %%tuner_operation_request.c:REPEAT%%
    }

    return 1;
}


