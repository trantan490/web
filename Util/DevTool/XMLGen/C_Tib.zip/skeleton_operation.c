int %%OperationName%%(%%caster_operation_parameter%%)
{
    // TODO : user code
    
    return IOI_SUCCESS;
}


