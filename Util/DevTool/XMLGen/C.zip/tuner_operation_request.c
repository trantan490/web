
        if(DT_REQUEST == (IOIMessageGetDelivery(msg) & 0x000f))
        {
            IOIMessage rep = IOIMessageCreateReply(msg);
            if(Null_Ptr != rep)
            {
                IxArray a_data;
                HStreamBuffer buffer = CreateStreamByteBuffer(Null_Ptr, IX_BYTE, 5, 10, 500);
                HOutputStream stream = CreateOutputStream(buffer);
                HTransformer  former = CreateWriteTransformer(stream);
                if(Null_Ptr != former)
                {
                    %%tuner_operation_parameter_serialize%%
                    DestroyTransformer(former);
                }

                DestroyOutputStream(stream);
                a_data = StreamBuffer_GetBytes(buffer);
                IOIMessageSetData(rep, a_data.pval, a_data.cnt); 
                DestroyStreamBuffer(buffer);
                array_destroy(&a_data);

                status = send_reply(session, msg, rep, status, "0");
                if(rep) IOIMessageRelease(rep);
            }
        }