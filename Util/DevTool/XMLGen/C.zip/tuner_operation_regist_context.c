    XGEN_OPERATION_REGIST_CONTEXT(%%OperationName%%)

