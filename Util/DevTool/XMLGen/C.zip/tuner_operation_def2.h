extern IOIStatus %%OperationName%%(%%caster_operation_parameter%%);

