extern IOIStatus recv_%%OperationName%%(IOISession session, IOIMessage msg);

