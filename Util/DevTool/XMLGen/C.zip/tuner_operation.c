IOIStatus recv_%%OperationName%%(IOISession session, IOIMessage msg)
{
    IOIStatus status = IOI_SUCCESS;
    
%%tuner_operation_parameter_def%%
    IxArray ioi_data_array = IOIMessageGetDataArray(msg);
    HTransformer former = CreateByteTransformer(&ioi_data_array);
    
    if(Null_Ptr != former)
    {
        %%tuner_operation_parameter_transform%%
        DestroyTransformer(former);

        %%OperationName%%(%%tuner_operation_parameter_name%%); /* Call User Procedure */
        %%tuner_operation_request.c:REPEAT%%
    }

    return status;
}


